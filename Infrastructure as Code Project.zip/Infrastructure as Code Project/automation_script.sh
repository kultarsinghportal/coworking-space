#!/bin/bash
# Automation script for CloudFormation templates. 
#
# Parameters
#   $1: Execution mode. Valid values: create, delete, update.
#
# Usage examples:
#   ./automation_script.sh create 
#   ./automation_script.sh update
#   ./automation_script.sh delete
#

# Validate parameters
if [[ $1 != "create" && $1 != "delete" && $1 != "update" ]]; then
    echo "ERROR: Incorrect Operationi, Please choose the valid operation." >&2
    exit 1
fi



# Execute CloudFormation CLI
if [ $1 == "create" ]
then
    aws cloudformation create-stack \
    --stack-name $2 \
    --template-body file://$3   \
    --parameters file://$4  \
    --capabilities "CAPABILITY_NAMED_IAM"  \
    --region=us-east-1
fi

if [ $1 == "delete" ]
then
    aws cloudformation delete-stack \
        --stack-name $2
fi

if [ $1 == "update" ]
then
    aws cloudformation update-stack \
    --stack-name $2 \
    --template-body file://$3   \
    --parameters file://$4  \
    --capabilities "CAPABILITY_NAMED_IAM"  \
    --region=us-east-1
    --no-execute-changeset
fi
