# CD12352 - Infrastructure as Code Project Solution
# Kultar Singh

## Spin up instructions
Step1 - To create  network infrastructure run the below script, this will create the network stack on AWS
./automation_script.sh create KultarUdacityNetworkStack network.yml network-parameters.json

Step2 - Once Network stack is created, Then the application stack can be created, thsi will create the application stack on AWS
./automation_script.sh create KultarUdacityApplicationStack udagram.yml udagram-parameters.json

## Tear down instructions
To delete stacks:
Step1 - To delete the Application stack 
./automation_script.sh delete KultarUdacityApplicationStack 

Step2 - To delete the Network stack 
./automation_script.sh delete KultarUdacityNetworkStack 

## Other considerations
URL: http://kultar-webap-i2gc6uzhlqac-329078907.us-east-1.elb.amazonaws.com/index.html